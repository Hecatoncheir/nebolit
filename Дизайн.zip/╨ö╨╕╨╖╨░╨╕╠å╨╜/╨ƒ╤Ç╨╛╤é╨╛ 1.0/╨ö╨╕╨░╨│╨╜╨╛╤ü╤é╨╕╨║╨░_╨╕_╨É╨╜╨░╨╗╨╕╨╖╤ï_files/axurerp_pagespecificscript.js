﻿for(var i = 0; i < 181; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u122'] = 'center';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u156'] = 'center';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u168'] = 'center';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u138'] = 'center';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u144'] = 'center';gv_vAlignTable['u110'] = 'top';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u150'] = 'center';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u148'] = 'center';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u176'] = 'center';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u164'] = 'center';gv_vAlignTable['u146'] = 'center';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u174'] = 'center';gv_vAlignTable['u128'] = 'center';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u180'] = 'center';gv_vAlignTable['u114'] = 'top';gv_vAlignTable['u166'] = 'center';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u34'] = 'center';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u160'] = 'center';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u142'] = 'center';gv_vAlignTable['u106'] = 'top';document.getElementById('u53_img').tabIndex = 0;

u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u116'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u130'] = 'center';gv_vAlignTable['u170'] = 'center';gv_vAlignTable['u134'] = 'center';gv_vAlignTable['u172'] = 'center';gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u140'] = 'center';gv_vAlignTable['u162'] = 'center';gv_vAlignTable['u89'] = 'center';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u136'] = 'center';gv_vAlignTable['u152'] = 'center';gv_vAlignTable['u132'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u154'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u178'] = 'center';gv_vAlignTable['u96'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u120'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u158'] = 'center';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u126'] = 'center';