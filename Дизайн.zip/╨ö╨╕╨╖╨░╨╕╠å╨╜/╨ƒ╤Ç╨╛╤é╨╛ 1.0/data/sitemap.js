﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m),_(c,n,e,f,g,o),_(c,p,e,f,g,q)])]);}; 
var b="rootNodes",c="pageName",d="Главная",e="type",f="Wireframe",g="url",h="Главная.html",i="children",j="Клиника на Ленинском",k="Клиника_на_Ленинском.html",l="Диагностика и Анализы",m="Диагностика_и_Анализы.html",n="Стоимость услуг",o="Стоимость_услуг.html",p="Аллерголог-иммунолог",q="Аллерголог-иммунолог.html";
return _creator();
})();
